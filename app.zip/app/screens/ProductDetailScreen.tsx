import React, { useState } from 'react';
import {
    FlatList,
    Image,
    ScrollView,
    StyleSheet,
    Text,
    TouchableOpacity,
    View
} from 'react-native';

const ProductDetailScreen = () => {
  const [selectedColor, setSelectedColor] = useState(0);
  const [selectedSize, setSelectedSize] = useState('M');
  const [quantity, setQuantity] = useState(1);

  const colors = [
    { id: 1, uri: 'https://via.placeholder.com/80/FF0000' },
    { id: 2, uri: 'https://via.placeholder.com/80/00FF00' },
    { id: 3, uri: 'https://via.placeholder.com/80/0000FF' },
    { id: 4, uri: 'https://via.placeholder.com/80/FFFF00' },
  ];

  const sizes = ['S', 'M', 'L', 'XL', 'XXL'];

  return (
    <ScrollView style={styles.container}>
      {/* Ảnh lớn */}
      <Image
        source={{ uri: colors[selectedColor].uri }}
        style={styles.productImage}
      />

      {/* Thông tin sản phẩm */}
      <View style={styles.content}>
        <Text style={styles.price}>$17.00</Text>
        <Text style={styles.description}>
          Lorem ipsum dolor sit amet, consectetur adipiscing elit...
        </Text>

        {/* Chọn màu */}
        <Text style={styles.label}>Color Options</Text>
        <FlatList
          horizontal
          data={colors}
          renderItem={({ item, index }) => (
            <TouchableOpacity onPress={() => setSelectedColor(index)}>
              <Image
                source={{ uri: item.uri }}
                style={[
                  styles.colorOption,
                  index === selectedColor && styles.selectedBorder,
                ]}
              />
            </TouchableOpacity>
          )}
          keyExtractor={(item) => item.id.toString()}
          showsHorizontalScrollIndicator={false}
        />

        {/* Chọn size */}
        <Text style={styles.label}>Size</Text>
        <View style={styles.sizeContainer}>
          {sizes.map((sz) => (
            <TouchableOpacity
              key={sz}
              style={[
                styles.sizeBox,
                selectedSize === sz && styles.selectedSize,
              ]}
              onPress={() => setSelectedSize(sz)}
            >
              <Text>{sz}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Số lượng */}
        <Text style={styles.label}>Quantity</Text>
        <View style={styles.quantityContainer}>
          <TouchableOpacity onPress={() => setQuantity(Math.max(1, quantity - 1))}>
            <Text style={styles.quantityButton}>-</Text>
          </TouchableOpacity>
          <Text style={styles.quantityValue}>{quantity}</Text>
          <TouchableOpacity onPress={() => setQuantity(quantity + 1)}>
            <Text style={styles.quantityButton}>+</Text>
          </TouchableOpacity>
        </View>

        {/* Nút */}
        <View style={styles.buttonRow}>
          <TouchableOpacity style={styles.cartBtn}>
            <Text style={styles.buttonText}>Add to cart</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.buyBtn}>
            <Text style={styles.buttonText}>Buy now</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  productImage: { width: '100%', height: 300 },
  content: { padding: 16 },
  price: { fontSize: 24, fontWeight: 'bold', color: '#000' },
  description: { marginTop: 8, fontSize: 14, color: '#555' },

  label: { marginTop: 16, fontSize: 16, fontWeight: 'bold' },

  colorOption: {
    width: 60,
    height: 60,
    borderRadius: 12,
    marginRight: 10,
    marginTop: 8,
  },
  selectedBorder: {
    borderWidth: 2,
    borderColor: '#000',
  },

  sizeContainer: { flexDirection: 'row', marginTop: 8 },
  sizeBox: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    paddingVertical: 8,
    paddingHorizontal: 14,
    marginRight: 10,
  },
  selectedSize: {
    backgroundColor: '#000',
    borderColor: '#000',
    color: '#fff',
  },

  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    gap: 12,
  },
  quantityButton: {
    fontSize: 22,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 6,
  },
  quantityValue: {
    fontSize: 18,
    minWidth: 30,
    textAlign: 'center',
  },

  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 24,
  },
  cartBtn: {
    backgroundColor: '#333',
    padding: 14,
    borderRadius: 10,
    flex: 1,
    marginRight: 10,
  },
  buyBtn: {
    backgroundColor: '#007BFF',
    padding: 14,
    borderRadius: 10,
    flex: 1,
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold',
  },
});


export default ProductDetailScreen;
