// CartScreen.tsx
import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
import {
  getCartItemsByEmail,
  getCartsByEmail,
  getSavedCartId,
  getUserEmail,
  saveCartId,
  updateCartItemQtyById,
  updateCartProductQtyByEmail,
} from '../Api/ApiService';
import { CartItem, useCart } from './context/CartContext';

const CartScreen = () => {
  const { cartItems, updateQuantity, removeFromCart, getTotalPrice, replaceCart } = useCart();

  const [email, setEmail] = useState<string | null>(null);
  const [cartId, setCartId] = useState<string | number | null>(null);
  const [loading, setLoading] = useState(true);

  // --- Helper: map raw item từ API -> CartItem của context
  const mapRawToCartItem = (x: any): CartItem => ({
    id: Number(x.productId ?? x.product?.id ?? x.id), // productId bắt buộc
    name: String(x.productName ?? x.product?.name ?? x.name ?? ''),
    price: Number(x.price ?? x.unitPrice ?? x.specialPrice ?? x.product?.price ?? 0),
    image:
      x.imageUrl ??
      x.image ??
      x.product?.imageUrl ??
      x.product?.image ??
      'https://via.placeholder.com/100',
    color: x.color ?? x.variantColor ?? null,
    size: x.size ?? x.variantSize ?? null,
    quantity: Number(x.quantity ?? 1),
    cartItemId: x.id ?? x.cartItemId, // id dòng cart trên backend (nếu có)
  });

  // --- Nạp email + cartId
  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const savedEmail = await getUserEmail();
        setEmail(savedEmail);

        if (!savedEmail) {
          setCartId(null);
          replaceCart([]); // không có email thì clear giỏ
          return;
        }

        let cid = await getSavedCartId();
        if (!cid) {
          const carts = await getCartsByEmail(savedEmail);
          if (carts?.length > 0) {
            cid = carts[0].cartId ?? carts[0].id;
            if (cid) await saveCartId(cid);
          }
        }
        setCartId(cid ?? null);
      } catch {
        // ignore
      } finally {
        setLoading(false);
      }
    })();
  }, [replaceCart]);

  // --- Nạp items theo email + cartId
  useEffect(() => {
    if (!email || !cartId) return;
    (async () => {
      setLoading(true);
      try {
        const rawItems = await getCartItemsByEmail(email, cartId);
        const mapped: CartItem[] = (rawItems || []).map(mapRawToCartItem);
        replaceCart(mapped);
      } finally {
        setLoading(false);
      }
    })();
  }, [email, cartId, replaceCart]);

  // --- Key cho FlatList: ưu tiên cartItemId để tránh trùng biến thể
  const keyExtractor = (item: CartItem) =>
    (item as any).cartItemId
      ? String((item as any).cartItemId)
      : `${item.id}-${item.color ?? 'no-color'}-${item.size ?? 'no-size'}`;

  // --- Handlers tăng/giảm
  const handleIncrease = async (productId: number) => {
    const item = cartItems.find((i) => i.id === productId);
    if (!item) return;
    const newQty = item.quantity + 1;
    updateQuantity(productId, newQty);

    try {
      if ((item as any).cartItemId) {
        await updateCartItemQtyById((item as any).cartItemId, newQty);
      } else if (email && cartId) {
        await updateCartProductQtyByEmail(String(email), String(cartId), productId, newQty);
      }
    } catch {
      // bạn có thể rollback state nếu cần
    }
  };

  const handleDecrease = async (productId: number) => {
    const item = cartItems.find((i) => i.id === productId);
    if (!item || item.quantity <= 1) return;
    const newQty = item.quantity - 1;
    updateQuantity(productId, newQty);

    try {
      if ((item as any).cartItemId) {
        await updateCartItemQtyById((item as any).cartItemId, newQty);
      } else if (email && cartId) {
        await updateCartProductQtyByEmail(String(email), String(cartId), productId, newQty);
      }
    } catch {
      // rollback nếu muốn
    }
  };

  const handleRemove = (productId: number) => {
    // Nếu muốn xoá đúng 1 dòng theo cartItemId, bạn có thể viết thêm removeByCartItemId trong ApiService + Context
    removeFromCart(productId);
  };

  const totalText = useMemo(
    () => `${getTotalPrice().toLocaleString('vi-VN')} ₫`,
    [getTotalPrice, cartItems]
  );

  const renderItem = ({ item }: { item: CartItem }) => (
    <View style={styles.cartItem}>
      <Image source={{ uri: item.image }} style={styles.image} />
      <View style={styles.info}>
        <Text numberOfLines={2} style={styles.name}>
          {item.name}
        </Text>
        <Text style={styles.variant}>
          {item.color ?? 'Default'}, Size {item.size ?? 'M'}
        </Text>
        <Text style={styles.price}>{(item.price || 0).toLocaleString('vi-VN')} ₫</Text>
      </View>

      <View style={styles.actions}>
        <TouchableOpacity onPress={() => handleRemove(item.id)}>
          <Icon name="trash" size={20} color="red" />
        </TouchableOpacity>

        <View style={styles.quantityControl}>
          <TouchableOpacity onPress={() => handleDecrease(item.id)}>
            <Text style={styles.qButton}>−</Text>
          </TouchableOpacity>
          <Text style={styles.quantity}>{item.quantity}</Text>
          <TouchableOpacity onPress={() => handleIncrease(item.id)}>
            <Text style={styles.qButton}>+</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={[styles.container, styles.center]}>
        <ActivityIndicator size="large" />
        <Text style={{ marginTop: 8 }}>Đang tải giỏ hàng…</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Header địa chỉ (tuỳ bạn thay bằng component riêng) */}
      <View style={styles.addressRow}>
        <Text style={styles.addressLabel}>Shipping Address</Text>
        <Icon name="edit" size={18} color="#007BFF" />
      </View>
      <Text style={styles.addressText}>123 Đường ABC, Quận 1, TP.HCM</Text>

      <FlatList
        data={cartItems}
        keyExtractor={keyExtractor}
        renderItem={renderItem}
        contentContainerStyle={{ paddingBottom: 16 }}
        ListEmptyComponent={
          <Text style={{ textAlign: 'center', marginTop: 32 }}>Giỏ hàng trống</Text>
        }
        ListFooterComponent={
          <View style={styles.footer}>
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>Total:</Text>
              <Text style={styles.totalValue}>{totalText}</Text>
            </View>
            <TouchableOpacity style={styles.checkoutButton}>
              <Text style={styles.checkoutText}>Checkout</Text>
            </TouchableOpacity>
          </View>
        }
      />
    </View>
  );
};

export default CartScreen;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f9f9f9', padding: 16 },
  center: { alignItems: 'center', justifyContent: 'center' },

  addressRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  addressLabel: { fontSize: 14, fontWeight: '600' },
  addressText: { fontSize: 14, color: '#555', marginBottom: 16 },

  cartItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 12,
    marginBottom: 12,
    elevation: 2,
  },
  image: { width: 70, height: 70, borderRadius: 10 },
  info: { flex: 1, marginLeft: 12 },
  name: { fontWeight: 'bold', fontSize: 16 },
  variant: { fontSize: 14, color: '#666', marginVertical: 4 },
  price: { fontSize: 15, color: '#007BFF', fontWeight: '600' },

  actions: { alignItems: 'flex-end', justifyContent: 'space-between', height: '100%' },
  quantityControl: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
  qButton: { fontSize: 20, color: '#007BFF', paddingHorizontal: 10 },
  quantity: { fontSize: 16, marginHorizontal: 6 },

  footer: {
    padding: 16,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderColor: '#eee',
    marginTop: 8,
    borderRadius: 12,
  },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10 },
  totalLabel: { fontSize: 16, fontWeight: 'bold' },
  totalValue: { fontSize: 16, color: '#007BFF', fontWeight: 'bold' },
  checkoutButton: {
    backgroundColor: '#28a745',
    padding: 14,
    borderRadius: 10,
    alignItems: 'center',
  },
  checkoutText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});
