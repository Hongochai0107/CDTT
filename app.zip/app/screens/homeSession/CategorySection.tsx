// CategorySection.tsx
import { Ionicons } from '@expo/vector-icons';
import React from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';

const categories = [
  {
    title: 'Clothing',
    count: 109,
    images: [
    //   require('./assets/clothing1.jpg'),
    //   require('./assets/clothing2.jpg'),
    //   require('./assets/clothing3.jpg'),
    //   require('./assets/clothing4.jpg'),
    ],
  },
  {
    title: 'Shoes',
    count: 530,
    images: [
    //   require('./assets/shoes1.jpg'),
    //   require('./assets/shoes2.jpg'),
    //   require('./assets/shoes3.jpg'),
    //   require('./assets/shoes4.jpg'),
    ],
  },
  {
    title: 'Bags',
    count: 87,
    images: [
    //   require('./assets/bags1.jpg'),
    //   require('./assets/bags2.jpg'),
    //   require('./assets/bags3.jpg'),
    //   require('./assets/bags4.jpg'),
    ],
  },
  {
    title: 'Lingerie',
    count: 218,
    images: [
    //   require('./assets/lingerie1.jpg'),
    //   require('./assets/lingerie2.jpg'),
    //   require('./assets/lingerie3.jpg'),
    //   require('./assets/lingerie4.jpg'),
    ],
  },
  {
    title: 'Watch',
    count: 218,
    images: [
    //   require('./assets/watch1.jpg'),
    //   require('./assets/watch2.jpg'),
    //   require('./assets/watch3.jpg'),
    //   require('./assets/watch4.jpg'),
    ],
  },
  {
    title: 'Hoodies',
    count: 218,
    images: [
    //   require('./assets/hoodie1.jpg'),
    //   require('./assets/hoodie2.jpg'),
    //   require('./assets/hoodie3.jpg'),
    //   require('./assets/hoodie4.jpg'),
    ],
  },
];

export default function CategorySection() {
  return (
    <>
      <View style={styles.sectionHeader}>
        <Text style={styles.sectionTitle}>Categories</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Text style={styles.seeAll}>See All</Text>
          <Ionicons name="arrow-forward" size={16} color="#007aff" />
        </View>
      </View>

      <View style={styles.categoryGrid}>
        {categories.map((cat, idx) => (
          <View key={idx} style={styles.categoryCard}>
            <View style={styles.categoryImagesGrid}>
              {cat.images.map((img, i) => (
                <Image key={i} source={img} style={styles.categoryImage} />
              ))}
            </View>
            <View style={styles.categoryFooter}>
              <Text style={styles.categoryTitle}>{cat.title}</Text>
              <View style={styles.categoryCountBox}>
                <Text style={styles.categoryCount}>{cat.count}</Text>
              </View>
            </View>
          </View>
        ))}
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
    marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
  },
  seeAll: {
    color: '#007aff',
    marginRight: 5,
  },
  categoryGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  categoryCard: {
    width: '48%',
    marginBottom: 20,
    borderRadius: 10,
    backgroundColor: '#fff',
    elevation: 2,
    padding: 10,
  },
  categoryImagesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  categoryImage: {
    width: '48%',
    height: 60,
    borderRadius: 6,
    marginBottom: 6,
  },
  categoryFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
  categoryTitle: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  categoryCountBox: {
    backgroundColor: '#f1f1f1',
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  categoryCount: {
    fontSize: 12,
    fontWeight: 'bold',
    color: '#333',
  },
});
