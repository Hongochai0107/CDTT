import React from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';


const productsColumn1 = [
  { id: 1, uri: require('../../../assets/images/flashsales1.png'), price: '$17.00' },
  { id: 3, uri: require('../../../assets/images/flashsales3.png'), price: '$17.00' },
  { id: 5, uri: require('../../../assets/images/flashsales5.png'), price: '$17.00' },
];

const productsColumn2 = [
  { id: 2, uri: require('../../../assets/images/flashsales2.png'), price: '$17.00' },
  { id: 4, uri: require('../../../assets/images/flashsales4.png'), price: '$17.00' },
  { id: 6, uri: require('../../../assets/images/flashsales6.png'), price: '$17.00' },
];

const JustForYouSection = () => {
  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <Text style={styles.title}>Just For You</Text>
        <Text style={styles.star}>★</Text>
      </View>
      <View style={styles.productGrid}>
        <View style={styles.column}>
          {productsColumn1.map((item) => (
            <View key={item.id} style={styles.productCardGrid}>
              <Image source={item.uri} style={styles.productImage} />
              <Text style={styles.productPrice}>{item.price}</Text>
            </View>
          ))}
        </View>
        <View style={[styles.column, { marginTop: 30 }]}>
          {productsColumn2.map((item) => (
            <View key={item.id} style={styles.productCardGrid}>
              <Image source={item.uri} style={styles.productImage} />
              <Text style={styles.productPrice}>{item.price}</Text>
            </View>
          ))}
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
  },
  headerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  title: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  star: {
    marginLeft: 6,
    fontSize: 18,
    color: '#007bff',
  },
  productGrid: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  column: {
    width: '48%',
  },
  productCardGrid: {
    alignItems: 'center',
    marginBottom: 15,
    backgroundColor: '#fff',
    borderRadius: 10,
    elevation: 2,
    overflow: 'hidden',
  },
  productImage: {
    width: '100%',
    height: 170,
    resizeMode: 'cover',
  },
  productPrice: {
    fontWeight: 'bold',
    fontSize: 14,
    marginVertical: 8,
    color: '#333',
  },
});

export default JustForYouSection;
