import React, { createContext, useContext, useState } from 'react';

export type CartItem = {
  /** productId trên backend */
  id: number;
  name: string;
  price: number;
  image: string;
  color?: string;
  size?: string;
  quantity: number;

  /** id của cart-item trên backend (nếu có) — dùng để update/xoá chính xác */
  cartItemId?: number | string;
};

type CartContextType = {
  cartItems: CartItem[];
  addToCart: (item: CartItem) => void;
  removeFromCart: (id: number) => void;
  updateQuantity: (id: number, quantity: number) => void;
  clearCart: () => void;
  getTotalPrice: () => number;

  /** ==> BỔ SUNG: thay toàn bộ giỏ bằng dữ liệu lấy từ backend */
  replaceCart: (items: CartItem[]) => void;
};

const CartContext = createContext<CartContextType>({
  cartItems: [],
  addToCart: () => {},
  removeFromCart: () => {},
  updateQuantity: () => {},
  clearCart: () => {},
  getTotalPrice: () => 0,
  replaceCart: () => {},
});

export const CartProvider = ({ children }: { children: React.ReactNode }) => {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const addToCart = (item: CartItem) => {
    setCartItems((prev) => {
      // Gộp theo product + biến thể (color/size). Nếu muốn gộp theo cartItemId thì đổi điều kiện tại đây.
      const existing = prev.find(
        (p) => p.id === item.id && p.size === item.size && p.color === item.color
      );
      if (existing) {
        return prev.map((p) =>
          p.id === item.id && p.size === item.size && p.color === item.color
            ? { ...p, quantity: p.quantity + item.quantity }
            : p
        );
      }
      return [...prev, item];
    });
  };

  const removeFromCart = (id: number) => {
    // Lưu ý: sẽ xoá tất cả biến thể có cùng productId.
    // Nếu muốn xoá đúng 1 dòng theo cartItemId, bạn có thể tạo thêm removeByCartItemId(cartItemId).
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  const updateQuantity = (id: number, quantity: number) => {
    setCartItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, quantity } : item))
    );
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const getTotalPrice = () => {
    return cartItems.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  /** ==> BỔ SUNG: thay toàn bộ giỏ từ dữ liệu backend đã map về CartItem */
  const replaceCart = (items: CartItem[]) => {
    setCartItems(items);
  };

  return (
    <CartContext.Provider
      value={{
        cartItems,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        getTotalPrice,
        replaceCart,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
