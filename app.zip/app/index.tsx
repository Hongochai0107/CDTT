import { createNativeStackNavigator } from '@react-navigation/native-stack';
import React from 'react';
import CartScreen from './screens/CartScreen';
import HomeScreen from './screens/HomeScreen';
import HomeTab from './screens/homeTabs/HomeTab';
import ProductDetailScreen from './screens/ProductDetailScreen';
import ProfileScreen from './screens/ProfileScreen';

export type RootStackParamList = {
  ProductDetail: undefined;
  Main: undefined;
  Home: undefined;
  Cart: undefined;
  Profile: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

const App = () => {
  return (
    <Stack.Navigator initialRouteName="Main">
      <Stack.Screen
        name="Home"
        component={HomeScreen}
        options={{ headerShown: false }}
      />

      <Stack.Screen
        name="ProductDetail"
        component={ProductDetailScreen}
        options={{ title: 'Chi tiết sản phẩm' }}
      />
      
      <Stack.Screen
        name="Cart"
        component={CartScreen}
        options={{ title: 'Giỏ hàng' }}
      />

      <Stack.Screen
        name="Profile"
        component={ProfileScreen}
        options={{ headerShown: false }}
      />

      <Stack.Screen
        name="Main"
        component={HomeTab}
        options={{ headerShown: false }}
      />

    </Stack.Navigator>
  );
};

export default App;
