// ApiService.tsx
import AsyncStorage from '@react-native-async-storage/async-storage';
import axios, { AxiosError, AxiosHeaders, AxiosInstance, AxiosRequestConfig, AxiosResponse } from 'axios';
/**
 * ============================================
 *           CẤU HÌNH CƠ BẢN
 * ============================================
 * LƯU Ý: nếu chạy trên thiết bị thật, KHÔNG dùng localhost.
 * Hãy đổi sang IP LAN của máy (VD: http://192.168.1.10:8080/api)
 */
const API_URL = process.env.EXPO_PUBLIC_API_URL?.trim() || 'http://localhost:8080/api';

/** Key lưu trữ trong AsyncStorage */
const AS_KEY_TOKEN = 'jwt-token';
const AS_KEY_EMAIL = 'user-email';
const AS_KEY_USER_INFO = 'user-info';
const AS_KEY_CART_ID = 'cart-id';

/**
 * ============================================
 *           AXIOS INSTANCE + INTERCEPTOR
 * ============================================
 */
const api: AxiosInstance = axios.create({
  baseURL: API_URL,
  timeout: 15000,
  headers: {
    'Content-Type': 'application/json',
  },
});



api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem(AS_KEY_TOKEN);
  if (token) {
    if (!config.headers) {
      config.headers = new AxiosHeaders();
    }
    (config.headers as AxiosHeaders).set('Authorization', `Bearer ${token}`);
  }
  return config;
});


/** Log lỗi chuẩn cho mọi request */
function logAxiosError(method: string, endpoint: string, error: unknown) {
  if (axios.isAxiosError(error)) {
    const err = error as AxiosError<any>;
    console.error(`API ${method.toUpperCase()} ${endpoint} thất bại:`, err.response?.data || err.message);
  } else {
    console.error(`API ${method.toUpperCase()} ${endpoint} thất bại:`, error);
  }
}

/**
 * ============================================
 *           HÀM GỌI API TỔNG QUÁT
 * ============================================
 */
async function callApi<T = any>(
  endpoint: string,
  method: AxiosRequestConfig['method'],
  data?: any
): Promise<AxiosResponse<T>> {
  try {
    const res = await api.request<T>({ url: `/${endpoint}`, method, data });
    return res;
  } catch (error) {
    logAxiosError(method || 'GET', endpoint, error);
    throw error;
  }
}

/** ================== CRUD NGẮN GỌN ================== */
export function GET_ALL<T = any>(endpoint: string) {
  return callApi<T>(endpoint, 'GET');
}
export function GET_ID<T = any>(endpoint: string, id: string | number) {
  return callApi<T>(`${endpoint}/${id}`, 'GET');
}
export function GET_IMAGE<T = any>(endpoint: string, id: string | number) {
  return callApi<T>(`${endpoint}/${id}`, 'GET');
}
export function GET_PAGE<T = any>(
  endpoint: string,
  page: number = 0,
  size: number = 10,
  categoryId: string | null = null
) {
  let url = `${endpoint}?page=${page}&size=${size}`;
  if (categoryId) url += `&categoryId=${categoryId}`;
  return callApi<T>(url, 'GET');
}
export function POST<T = any>(endpoint: string, data: any) {
  return callApi<T>(endpoint, 'POST', data);
}
export function PUT<T = any>(endpoint: string, data: any) {
  return callApi<T>(endpoint, 'PUT', data);
}
export function PATCH<T = any>(endpoint: string, data: any) {
  return callApi<T>(endpoint, 'PATCH', data);
}
export function DELETE_ID<T = any>(endpoint: string, id: string | number) {
  return callApi<T>(`${endpoint}/${id}`, 'DELETE');
}

/**
 * ============================================
 *           AUTH + USER HELPERS
 * ============================================
 */
export async function saveUserEmail(email: string) {
  try {
    await AsyncStorage.setItem(AS_KEY_EMAIL, email);
  } catch (e) {
    console.error('Lỗi lưu email:', e);
  }
}

export async function getUserEmail() {
  try {
    return await AsyncStorage.getItem(AS_KEY_EMAIL);
  } catch {
    return null;
  }
}

export async function saveCartId(cartId: string | number) {
  try {
    await AsyncStorage.setItem(AS_KEY_CART_ID, String(cartId));
  } catch (e) {
    console.error('Lỗi lưu cart-id:', e);
  }
}

export async function getSavedCartId() {
  try {
    return await AsyncStorage.getItem(AS_KEY_CART_ID);
  } catch {
    return null;
  }
}

/** Lấy token JWT từ AsyncStorage */
async function getToken(): Promise<string | null> {
  try {
    return await AsyncStorage.getItem(AS_KEY_TOKEN);
  } catch (error) {
    console.error('Lỗi lấy token:', error);
    return null;
  }
}

/** Đăng ký */
export const registerUser = async (username: string, password: string) => {
  const response = await POST('auth/register', { username, password });
  return response.data;
};

/** Lấy user info theo email */
export async function getUserInfoByEmail(email: string) {
  try {
    const res = await GET_ALL(`public/users/email/${email}`);
    return res.data;
  } catch {
    return null;
  }
}

/** Lấy profile user (dựa theo email đã lưu trong AsyncStorage) */
export async function getUserProfile() {
  try {
    const email = await AsyncStorage.getItem(AS_KEY_EMAIL);
    if (!email) return null;
    const res = await GET_ALL(`public/users/email/${email}`);
    return res.data;
  } catch {
    return null;
  }
}

/** Đăng nhập:
 *  - Xóa token cũ
 *  - POST login
 *  - Lưu token mới (nếu có)
 *  - Lưu email
 *  - Prefetch carts theo email và lưu cart-id đầu tiên (nếu có)
 *  - Lưu user-info (nếu lấy được)
 */
export const loginUser = async (email: string, password: string) => {
  // xoá token cũ
  await AsyncStorage.removeItem(AS_KEY_TOKEN);

  const response = await POST<any>('login', { email, password });

  // token
  const token = response.data?.[AS_KEY_TOKEN] || response.data?.token || response.data?.accessToken;
  if (token) {
    await AsyncStorage.setItem(AS_KEY_TOKEN, token);
  } else {
    await AsyncStorage.removeItem(AS_KEY_TOKEN);
  }

  // lưu email
  await AsyncStorage.setItem(AS_KEY_EMAIL, email);

  // lưu user-info
  try {
    const userInfo = await getUserInfoByEmail(email);
    if (userInfo && (userInfo.userId || userInfo.id)) {
      await AsyncStorage.setItem(AS_KEY_USER_INFO, JSON.stringify(userInfo));
    } else {
      await AsyncStorage.setItem(AS_KEY_USER_INFO, JSON.stringify(response.data));
    }
  } catch (e) {
    console.error('Lỗi lấy user info sau login:', e);
    await AsyncStorage.setItem(AS_KEY_USER_INFO, JSON.stringify(response.data));
  }

  // prefetch cart-id đầu tiên
  try {
    const carts = await getCartsByEmail(email);
    if (carts.length > 0) {
      const firstId = carts[0].cartId ?? carts[0].id;
      if (firstId) await saveCartId(firstId);
    }
  } catch {}

  return response.data;
};

/** Lấy userId đã lưu (nếu có) — tuỳ hệ thống bạn có cần hay không */
export async function getUserId() {
  try {
    const userInfo = await AsyncStorage.getItem(AS_KEY_USER_INFO);
    if (userInfo) {
      const user = JSON.parse(userInfo);
      return user.userId || user.id || null;
    }
    return null;
  } catch {
    return null;
  }
}

/**
 * ============================================
 *           CART THEO EMAIL / CART ID
 * ============================================
 */

/** Lấy danh sách carts theo email (luôn trả về mảng) */
export async function getCartsByEmail(email: string) {
  const res = await GET_ALL<any>(`public/users/${email}/carts`);
  const data = res.data;
  if (Array.isArray(data)) return data;
  if (data?.content && Array.isArray(data.content)) return data.content;
  if (data) return [data];
  return [];
}

/** Lấy items trong cart theo email + cartId (trả về mảng items thô) */
export async function getCartItemsByEmail(email: string, cartId: string | number) {
  const res = await GET_ALL<any>(`public/users/${email}/carts/${cartId}`);
  const data = res.data;
  if (Array.isArray(data?.items)) return data.items;
  if (Array.isArray(data)) return data;
  return [];
}

/** Thêm sản phẩm vào cart theo userId (API cũ) */
export function addProductToCart(userId: string | number, productId: number, quantity: number) {
  return POST(`public/carts/${userId}/products/${productId}/quantity/${quantity}`, {});
}

/** (Khuyến nghị) Thêm SP vào cart theo email + cartId */
export function addProductToCartByEmail(email: string, cartId: string | number, productId: number, quantity: number) {
  return POST(`public/users/${email}/carts/${cartId}/products/${productId}/quantity/${quantity}`, {});
}

/** Update số lượng theo cartItemId (nếu backend hỗ trợ) */
export function updateCartItemQtyById(cartItemId: number | string, quantity: number) {
  return PUT(`public/cart/items/${cartItemId}`, { quantity });
}

/** Update số lượng theo email + cartId + productId (nếu backend yêu cầu dạng này) */
export function updateCartProductQtyByEmail(email: string, cartId: string | number, productId: number | string, quantity: number) {
  return PUT(`public/users/${email}/carts/${cartId}/products/${productId}/quantity/${quantity}`, {});
}

/** Xoá 1 item theo cartItemId (nếu backend hỗ trợ) */
export function removeCartItemById(cartItemId: number | string) {
  return callApi(`public/cart/items/${cartItemId}`, 'DELETE');
}

/** Xoá 1 product khỏi cart theo email + cartId + productId */
export function removeProductFromCartByEmail(email: string, cartId: string | number, productId: number | string) {
  return callApi(`public/users/${email}/carts/${cartId}/products/${productId}`, 'DELETE');
}

/**
 * ============================================
 *           PRODUCTS & CATEGORIES
 * ============================================
 */
export const getAllProducts = async () => {
  const response = await GET_ALL('public/products?pageNumber=0&pageSize=20&sortBy=productId&sortOrder=asc');
  // tuỳ backend: content hoặc mảng
  return response.data?.content ?? response.data ?? [];
};

export const getProductById = async (productId: number) => {
  const response = await GET_ID('public/products', productId);
  return response.data;
};

export const getAllCategoriesWithProducts = async () => {
  try {
    const catResponse = await GET_ALL('public/categories');
    const categories = catResponse.data?.content ?? catResponse.data ?? [];

    const categoriesWithProducts = await Promise.all(
      categories.map(async (cat: any) => {
        try {
          const productResponse = await GET_ALL(`public/categories/${cat.categoryId}/products`);
          const productsRaw = productResponse.data?.content ?? productResponse.data ?? [];
          const topProducts = [...productsRaw]
            .filter((p) => typeof p.specialPrice === 'number')
            .sort((a, b) => a.specialPrice - b.specialPrice)
            .slice(0, 4);

          return {
            ...cat,
            productCount: productsRaw.length,
            products: topProducts,
          };
        } catch (error) {
          console.error(`Lỗi lấy sản phẩm của category ${cat.categoryId}:`, error);
          return { ...cat, productCount: 0, products: [] };
        }
      })
    );

    return categoriesWithProducts;
  } catch (error) {
    console.error('Lỗi khi lấy danh mục:', error);
    return [];
  }
};

export const getFlashSaleProducts = async () => {
  const response = await GET_ALL('public/products');
  const allProducts = response.data?.content ?? response.data ?? [];
  const flashSaleProducts = allProducts.filter((product: any) => {
    return (typeof product.discount === 'number' && product.discount > 0) ||
           (typeof product.specialPrice === 'number' &&
            product.specialPrice > 0 &&
            product.specialPrice < product.price);
  });
  return flashSaleProducts;
};
